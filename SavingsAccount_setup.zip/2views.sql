use banking;
/*--DROP VIEW `account_status` ;--*/
CREATE VIEW `account_status` AS 
select `lookup`.`icode` AS `id`,`lookup`.`value` AS `account_status` from `lookup` 
where `lookup`.`type` = 'account_status';

/*DROP VIEW `account_operation`;*/
CREATE VIEW `account_operation` AS 
select `lookup`.`icode` AS `id`,`lookup`.`value` AS `account_operation` from `lookup` 
where `lookup`.`type` = 'A/c operations';

/*DROP VIEW `account_type`;*/
CREATE VIEW `account_type` AS 
select `lookup`.`icode` AS `id`,`lookup`.`value` AS `account_type` from `lookup` 
where `lookup`.`type` = 'Account Type';

/*DROP VIEW `customer_type`;*/
CREATE VIEW `customer_type` AS 
select `lookup`.`icode` AS `id`,`lookup`.`value` AS `customer_type` from `lookup` 
where `lookup`.`type` = 'Customer_Type';

/*DROP VIEW `transaction_mode`;*/
CREATE VIEW `transaction_mode` AS 
select `lookup`.`icode` AS `id`,`lookup`.`value` AS `transaction_mode` from `lookup` 
where `lookup`.`type` = 'Transaction Mode';

/*DROP VIEW `transaction_type`;*/
CREATE VIEW `transaction_type` AS 
select `lookup`.`icode` AS `id`,`lookup`.`value` AS `transaction_type` from `lookup` 
where `lookup`.`type` = 'Transaction type';
